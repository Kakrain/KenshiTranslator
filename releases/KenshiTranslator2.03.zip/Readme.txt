Kenshi Translator — v2.03
Extracts strings from Kenshi .mod -> produces .dict -> translates -> applies back to .mod (backup created).

Installation:
1. Unzip the package to a folder.
2. Ensure LanguageModels folder is present.
3. Run KenshiTranslator.exe 

Usage:
1. Select a mod, pick provider, pick languages.
2. Click "Create Dictionary" (creates/updates .dict and performs translations).
3. When .dict reaches 100%, click "Translate Mod" to write translated .mod (a .backup will be made).

If translations fail, try a different provider or edit the .dict manually.
